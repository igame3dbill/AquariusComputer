#include <stdio.h>

int main (void)
{
	int ch, i, j=0;

	while ((ch = getc (stdin)) != EOF)
	{
		if (!(j % 8))
		{
			printf ("\n\nchr$(%d)\n", j / 8);
		}
		j++;

		for (i = 7; i > 0; i--)
		{
			if (ch & (1 << i))
			{
				putchar('#');
			}
			else
			{
				putchar('.');
			}
		}
		putchar('\n');
	}
	return 0;
}

